import {
  init_javascript,
  jsCopyGlobMulty,
  jsCopyGlobSingle,
  jsCopyMulty,
  jsCopySingle
} from "./chunk-4TCID4PF.js";
init_javascript();
export {
  jsCopyGlobMulty,
  jsCopyGlobSingle,
  jsCopyMulty,
  jsCopySingle
};
