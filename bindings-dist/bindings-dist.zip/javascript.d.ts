declare const jsCopyGlobMulty: (pattern: string[], outDir: string) => void;
declare const jsCopyGlobSingle: (pattern: string, outDir: string) => void;
declare const jsCopyMulty: (path: string[], outDir: string) => void;
declare const jsCopySingle: (path: string, outDir: string) => void;

export { jsCopyGlobMulty, jsCopyGlobSingle, jsCopyMulty, jsCopySingle };
