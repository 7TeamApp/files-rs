"use strict";Object.defineProperty(exports, "__esModule", {value: true});





var _chunkSYT4PYHAcjs = require('./chunk-SYT4PYHA.cjs');
_chunkSYT4PYHAcjs.init_javascript.call(void 0, );





exports.jsCopyGlobMulty = _chunkSYT4PYHAcjs.jsCopyGlobMulty; exports.jsCopyGlobSingle = _chunkSYT4PYHAcjs.jsCopyGlobSingle; exports.jsCopyMulty = _chunkSYT4PYHAcjs.jsCopyMulty; exports.jsCopySingle = _chunkSYT4PYHAcjs.jsCopySingle;
exports.default=module.exports